import pandas as pd

# Charger les données depuis le fichier CSV
monDataF = pd.read_csv("C:\\Users\\yanis\\Desktop\\BUT_R&T\\BUT1\\SAE15\\ADECal.csv",
                       encoding='Latin-1', delimiter=";",
                       names=['Date', 'HStart', 'HEnd', 'Location'], header=None)

# Convertir la colonne 'Date' en datetime
monDataF['Date'] = pd.to_datetime(monDataF['Date'], format="mixed")



# Trier le DataFrame par la colonne 'Date' par ordre croissant
monDataF = monDataF.sort_values(by='Date')

# Fonction qui demande la salle
def salle():
    uneSalle = str(input("Quelle est la salle ?")).upper()
    return uneSalle

# Fonction qui demande la date
def date():
    uneDate = str(input("Quelle date ? (AAAA-MM-JJ)"))
    return uneDate

# Fonction qui donne les 10 première lignes d'un tableau quand on défini une salle 
def rechercheSalle(s):
    salleDataF = monDataF[(monDataF["Location"] == s)]
    return salleDataF.head(10)

# Fonction qui donne les 10 première lignes d'un tableau quand on défini une date
def rechercheDate(d):
    dateDataF = monDataF[(monDataF["Date"] >= d)]
    return dateDataF.head(10)

# Fonction qui donne les 10 première lignes d'un tableau quand on défini une salle et une date
def rechercheSalleDate(s, d):
    salleDateDataF = monDataF[(monDataF["Location"] == s) & (monDataF["Date"] >= d)]
    return salleDateDataF.head(10)

# Fonction qui transforme la colone "HStart" en list quand une salle et une date sont données
def listHStart(s, d):
    salleDateDataF = monDataF[(monDataF["Location"] == s) & (monDataF["Date"] >= d)]
    uneListeHStart = salleDateDataF['HStart'].tolist()
    return uneListeHStart

# Fonction qui transforme la colone "HEnd" en list quand une salle et une date sont données
def listHEnd(s, d):
    salleDateDataF = monDataF[(monDataF["Location"] == s) & (monDataF["Date"] >= d)]
    uneListeHEnd = salleDateDataF['HEnd'].tolist()
    return uneListeHEnd

# Fonction qui calcul les crénaux disponible
#def crenauDispo(c, lHS, lHE, cP):
    listeCrenauDispo = []     

    return listeCrenauDispo

# Initialisation du crénau et des variables

crénaux = ["08:00:00", "09:00:00", "10:00:00", "11:00:00", "12:00:00", "13:30:00", "14:00:00", "14:30:00", "15:00:00", "15:30:00"]
crénauxPossible = ["8h-10h", "10h-12h", "13H30-15h30", "15h30-17h30"]
uneListeHEnd = []
uneListeHStart = []

# On demande si l'utilisateur a une salle ou une date précise.
avoirSalle = input("Avez-vous une salle ? (oui/non)").lower()
avoirDate = input("Avez-vous une date ? (oui/non)").lower() 

if avoirSalle == "oui" and avoirDate == "oui":
    uneSalle = salle()
    uneDate = date()
    print(f"Voici un tableau des crénaux occupé de la {uneSalle} à partir de la date du {uneDate}.")
    print(rechercheSalleDate(uneSalle, uneDate))

    # Utiliser les fonctions pour obtenir les listes des heures de début et de fin
    uneListeHStart = listHStart(uneSalle, uneDate)
    uneListeHEnd = listHEnd(uneSalle, uneDate)
    
    # Calculer les créneaux disponibles
    #crenauxDisponibles = crenauDispo(crénaux, uneListeHStart, uneListeHEnd, crénauxPossible)
    
    #print(f"Les créneaux disponibles sont : {crenauxDisponibles}")
elif avoirSalle == "oui" and avoirDate == "non":
    uneSalle = salle()
    print(f"La salle demandée est {uneSalle}.")
    print(rechercheSalle(uneSalle))
elif avoirSalle == "non" and avoirDate == "oui":
    uneDate = date()
    print(f"La date demandée est {uneDate}.")
    print(rechercheDate(uneDate))
else:
    print("Erreur, manque d'information sur la salle ou la date.")

